<?php
require_once("Banco.php");
$conexao = Banco::conecta("127.0.0.1","ronnye","ro078squ");
if($_POST["deputadosEmExercicio"])
{
    $sql = "CREATE DATABASE CidadaoDeOlho";
    $conexao->executaQuery($sql);
    $conexao->selecionaBanco("CidadaoDeOlho");

    $sql = "CREATE TABLE DEPUTADO(
        id INT NOT NULL,
        nome VARCHAR(100) NOT NULL,
        partido VARCHAR(5) NOT NULL,
        tagLocalizacao INT NOT NULL,
      PRIMARY KEY (id))";
    $conexao->executaQuery($sql);

    $arrayDeputadosEmExercicio = $_POST["arrayDeputadosEmExercicio"]["list"];
    $arrayIdDeputados = array();
    foreach($arrayDeputadosEmExercicio as $valor)
    {   

        $id = $valor["id"];
        $arrayIdDeputados[$id] = $id;
        $nome = $valor["nome"];
        $partido = $valor["partido"];
        $tagLocalizacao = $valor["tagLocalizacao"];
        $sql = "INSERT INTO DEPUTADO (id,nome,partido,tagLocalizacao) 
        VALUES ($id, '$nome', '$partido', $tagLocalizacao)";    
         
        $conexao->executaQuery($sql);    
    }
    
    echo json_encode($arrayIdDeputados);   
}
if($_POST["verbasIndenizatorias"])
{
    $conexao->selecionaBanco("CidadaoDeOlho");
    $arrayVerbasIndenizatorias = $_POST["arrayVerbasIndenizatorias"]["list"];
    foreach($arrayVerbasIndenizatorias as $valor)
    {
        $sql="CREATE TABLE VERBAS_INDENIZATORIAS (
                cod_verbas_indenizatorias INT NOT NULL AUTO_INCREMENT,
                idDeputado INT NOT NULL,
                dataReferencia DATE NOT NULL,
                codTipoDespesa INT NOT NULL,
                valor DECIMAL(10,2) NOT NULL,
                descTipoDespesa VARCHAR(120) NOT NULL,
              PRIMARY KEY (cod_verbas_indenizatorias))";
       $conexao->executaQuery($sql);             
              
        $idDeputado = $valor["idDeputado"];        
        $dataReferencia = $valor["dataReferencia"]["$"];       
        $codTipoDespesa = $valor["codTipoDespesa"];
        $valorDespesa = $valor["valor"];
        $descTipoDespesa = $valor["descTipoDespesa"];
        
        $sql ="INSERT INTO `CidadaoDeOlho`.`VERBAS_INDENIZATORIAS` (`idDeputado`, `dataReferencia`, `codTipoDespesa`, `valor`, `descTipoDespesa`) 
        VALUES ($idDeputado,'$dataReferencia',$codTipoDespesa,$valorDespesa,'$descTipoDespesa')";
        $conexao->executaQuery($sql);       
    }     
}
if($_POST["redesSociais"])
{
    $conexao->selecionaBanco("CidadaoDeOlho");
    $arrayRedesSociais = $_POST["arrayRedesSociais"]["deputado"];
    $idDeputado = $arrayRedesSociais["id"];
    
    foreach($arrayRedesSociais["redesSociais"] as $valor)
    {
        $nomeRedeSocial = $valor["redeSocial"]["nome"];
        
        $sql="CREATE TABLE REDES_SOCIAIS (
                cod_rede_social INT NOT NULL AUTO_INCREMENT,
                idDeputado INT NOT NULL,
                nomeRedeSocial VARCHAR(45) NOT NULL,
                PRIMARY KEY (`cod_rede_social`))";
        $conexao->executaQuery($sql);                
        
        
        $sql = "INSERT INTO REDES_SOCIAIS(idDeputado,nomeRedeSocial) VALUES ($idDeputado,'$nomeRedeSocial')";
        $conexao->executaQuery($sql);
    }
}











