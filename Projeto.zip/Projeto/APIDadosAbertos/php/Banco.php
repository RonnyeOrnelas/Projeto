<?php
class Banco extends mysqli 
{
    private $endereco;
    private $usuario;
    private $senha;
    private $banco;
    private static $conexao;
    
    private function __construct($endereco,$usuario,$senha)
    {
        $this->conexao = mysqli_connect($endereco,$usuario,$senha);       
        mysqli_set_charset($this->conexao,'utf8');
        
    }
    public static function conecta($endereco,$usuario,$senha)
    {
        //Garante uma unica instancia. Se nao existe uma conexao, criamos uma nova.
        if (!isset(self::$conexao))
        {
            self::$conexao = new Banco($endereco,$usuario,$senha);
        }
        //Retorna a conexao.
        return self::$conexao;
    }
    public function selecionaBanco($banco)
    {
        mysqli_select_db($this->conexao,$banco);
    }
    
    public function executaQuery($query)
    {
        $result = mysqli_query($this->conexao,$query);
        return $result;
    }
    public function executaFetchAssoc($result)
    {
       $row = mysqli_fetch_assoc($result);
       return $row;
    }
    
    public function fecha()
    {
        mysqli_close($this->conexao);
    }
}
