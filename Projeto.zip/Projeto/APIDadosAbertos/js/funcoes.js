/*-----------------------------------------------------------------------------------------------------------------------------------
|SCRIPT PARA CONSUMO DOS DADOS ABERTOS DA ASSEMBLEIA LEGISLATIVA DE MINAS GERAIS                                                    | 
|Autor: Ronnye Ornelas Alves                                                                                                        |
|Data de criacao: 06/06/2019                                                                                                        |
|                                                                                                                                   |
|                                                                                                                                   | ------------------------------------------------------------------------------------------------------------------------------------*/
//Consumindo dados da lista de deputados em exercicio
var url = "http://dadosabertos.almg.gov.br/ws/deputados/em_exercicio?formato=json";

$.getJSON(url, function (data) {             
    $.ajax({        
        url: "php/CriaBaseDeDados.php",
        type: "POST",
        async: false,        
        data: {"arrayDeputadosEmExercicio": data,"deputadosEmExercicio": 1},
        success: function(result){                           
            verbasIndenizatorias(result);
            redesSociais(result);
        }
    });    
});

function verbasIndenizatorias(arrayIdDeputado)
{
    var obj = JSON.parse(arrayIdDeputado);
    
    for(i in obj) 
    {
        var item = obj[i];
        for(var i = 0;i < 12;i++)
        {
            var url = "http://dadosabertos.almg.gov.br/ws/prestacao_contas/verbas_indenizatorias/deputados/"+item+"/2017/"+i+"?formato=json";
            $.getJSON(url, function (data) {
                $.ajax({        
                    url: "php/CriaBaseDeDados.php",
                    type: "POST",
                    async: false,        
                    data: {"arrayVerbasIndenizatorias": data,"verbasIndenizatorias": 1},
                        success: function(result){               
                          //  alert(result);           
                        }
                });     
            });
        }      
    }
} 

function redesSociais(arrayIdDeputado)
{
   var obj = JSON.parse(arrayIdDeputado);
    
   for(i in obj) 
   {
        var item = obj[i];
        var url = "http://dadosabertos.almg.gov.br/ws/deputados/"+item+"?formato=json";       
        
         $.getJSON(url, function (data) {
            $.ajax({        
                url: "php/CriaBaseDeDados.php",
                type: "POST",
                async: false,        
                data: {"arrayRedesSociais": data,"redesSociais": 1},
                    success: function(result){               
                        //alert(result);           
                    }
            });     
        });           
    }
}
