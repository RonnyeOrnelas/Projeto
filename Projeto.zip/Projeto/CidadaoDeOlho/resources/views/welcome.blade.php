<?php
$conexao = mysqli_connect("127.0.0.1","ronnye","ro078squ");       
mysqli_set_charset($conexao,'utf8');
mysqli_select_db($conexao,"CidadaoDeOlho");

$sql="SELECT 
            T2.nome, T2.partido, SUM(T1.valor) AS soma
        FROM
            VERBAS_INDENIZATORIAS T1
                INNER JOIN
            DEPUTADO T2 ON T1.idDeputado = T2.id
        WHERE
            T1.dataReferencia BETWEEN '2017-01-01' AND '2017-12-31'
        GROUP BY T1.idDeputado
        ORDER BY soma DESC
        LIMIT 5";
$query=mysqli_query($conexao,$sql);


$sqlRedes="SELECT 
                nomeRedeSocial, COUNT(nomeRedeSocial) AS somaRede
            FROM
                REDES_SOCIAIS
            GROUP BY nomeRedeSocial
            ORDER BY somaRede DESC";
$queryRedes=mysqli_query($conexao,$sqlRedes);         
?>
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
               
                margin: 0;
            }
            .title {
                text-align: center;
                font-size: 20px;
            }
      
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                    Top 5 Deputados que mais pediram verbas indenizatórias em 2017
                </div>
                
                <table class="bordered striped centered">
                    <tr>
                        <th>Nome</th>
                        <th>Partido</th>
                        <th>Valor</th>
                    </tr>
                    <?php
                        while($array=mysqli_fetch_array($query))
                        {
                            ?>
                            <tr>                                 
                                <td><?php echo $array["nome"]; ?></td>
                                <td><?php echo $array["partido"]; ?></td>
                                <td><?php echo "R$ ".number_format($array["soma"],2,',','.'); ?></td>
                            </tr>
                            <?php
                        } 

                    ?>
                </table>
                    
            </div>
            <div class="title m-b-md">
                    Ranking Redes Sociais Mais usadas pelos Deputados em Legislatura atual
            </div>
            
                <table class="bordered striped centered">
                    <tr>
                        <th>Nome da Rede Social</th>
                        <th>Quantidade de Deputados que Utilizam</th>                        
                    </tr>
                    <?php
                        while($arrayRedes=mysqli_fetch_array($queryRedes))
                        {
                            ?>
                            <tr>                                 
                                <td><?php echo $arrayRedes["nomeRedeSocial"]; ?></td>
                                <td><?php echo $arrayRedes["somaRede"]; ?></td>
                              
                            </tr>
                            <?php
                        } 

                    ?>
                </table>
          
        </div>
    </body>
</html>
